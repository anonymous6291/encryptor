Run 'Encryptor-GUI' by executing 'Encryptor-GUI.bat'.

@echo off
cd .\encryptor
java -noverify -jar .\Encryptor-GUI.jar

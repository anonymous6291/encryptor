#!/bin/bash
cd ./encryptor
java -noverify -jar ./Encryptor-GUI.jar

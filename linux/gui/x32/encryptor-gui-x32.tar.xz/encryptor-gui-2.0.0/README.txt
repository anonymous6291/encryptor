Please make 'Encryptor-GUI.sh' executable using chmod.

For example:
 
         chmod +x Encryptor-GUI.sh
